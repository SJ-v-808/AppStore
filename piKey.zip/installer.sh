#!/bin/bash


sudo apt-get update
sudo apt-get install python3-tk

app_name="piKeyboard"
cwd=$(pwd)
echo $cwd
./dab.sh $cwd/keypad.py $app_name $cwd/testi.png
./dab.sh pb $app_name
